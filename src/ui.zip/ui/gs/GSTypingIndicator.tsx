// src/ui/gs/GSTypingIndicator.tsx
import { useAppTheme } from '@/src/ui/themed';
import { useEffect, useMemo, useRef } from 'react';
import { Animated, View } from 'react-native';

/**
 * Simple 3-dot typing / thinking indicator (no extra deps).
 */
export default function GSTypingIndicator({ size = 6 }: { size?: number }) {
  const theme = useAppTheme();
  const a1 = useRef(new Animated.Value(0.3)).current;
  const a2 = useRef(new Animated.Value(0.3)).current;
  const a3 = useRef(new Animated.Value(0.3)).current;

  const dotStyle = useMemo(
    () => ({
      width: size,
      height: size,
      borderRadius: 999,
      backgroundColor: theme.colors.textMuted,
      marginRight: size,
    }),
    [size, theme.colors.textMuted],
  );

  useEffect(() => {
    const mk = (v: Animated.Value, delay: number) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(v, {
            toValue: 1,
            duration: 260,
            useNativeDriver: true,
          }),
          Animated.timing(v, {
            toValue: 0.3,
            duration: 260,
            useNativeDriver: true,
          }),
          Animated.delay(280),
        ]),
      );

    const a = Animated.parallel([mk(a1, 0), mk(a2, 120), mk(a3, 240)]);
    a.start();

    return () => {
      a.stop();
    };
  }, [a1, a2, a3]);

  return (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Animated.View style={[dotStyle, { opacity: a1 }]} />
      <Animated.View style={[dotStyle, { opacity: a2 }]} />
      <Animated.View
        style={[{ ...dotStyle, marginRight: 0 }, { opacity: a3 }]}
      />
    </View>
  );
}

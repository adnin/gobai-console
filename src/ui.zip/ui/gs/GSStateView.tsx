import React from 'react';

import { Box, Center, Spinner, VStack } from '@gluestack-ui/themed';

import GSButton from '@/src/ui/gs/GSButton';
import GSText from '@/src/ui/gs/GSText';
import { useAppTheme } from '@/src/ui/themed';

export function LoadingState({
  title,
  label,
  subtitle,
}: {
  /** Preferred */
  title?: string;
  /** Back-compat */
  label?: string;
  subtitle?: string;
}) {
  const theme = useAppTheme();
  const t = title ?? label ?? 'Loading…';

  return (
    <Center flex={1} bg={theme.colors.bg as any} px={theme.space[5]}>
      <VStack space="md" alignItems="center">
        <Spinner />
        <GSText variant="title">{t}</GSText>
        {subtitle ? (
          <GSText
            variant="caption"
            style={{ opacity: 0.75, textAlign: 'center' }}
          >
            {subtitle}
          </GSText>
        ) : null}
      </VStack>
    </Center>
  );
}

export function EmptyState({
  title,
  label,
  subtitle,
  actionLabel,
  onAction,
  right,
}: {
  /** Preferred */
  title?: string;
  /** Back-compat */
  label?: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
  right?: React.ReactNode;
}) {
  const theme = useAppTheme();
  const t = title ?? label ?? 'Nothing here yet';

  return (
    <Center flex={1} bg={theme.colors.bg as any} px={theme.space[5]}>
      <VStack space="md" alignItems="center">
        <GSText variant="title">{t}</GSText>
        {subtitle ? (
          <GSText
            variant="caption"
            style={{ opacity: 0.75, textAlign: 'center' }}
          >
            {subtitle}
          </GSText>
        ) : null}

        {actionLabel && onAction ? (
          <Box pt={theme.space[2]} alignSelf="stretch">
            <GSButton title={actionLabel} onPress={onAction} variant="secondary" />
          </Box>
        ) : null}

        {right ? <Box pt={theme.space[2]}>{right}</Box> : null}
      </VStack>
    </Center>
  );
}

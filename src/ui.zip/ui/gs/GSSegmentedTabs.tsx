import TText from '@/src/ui/gs/GSText';
import { Box, Pressable as GSPressable, HStack } from '@gluestack-ui/themed';
import { History, Truck } from 'lucide-react-native';
import React, { useMemo } from 'react';
import { View } from 'react-native';

export type DefaultTabKey = 'active' | 'history';

export type SegmentedTabItem<K extends string> = {
  key: K;
  label: string;
  Icon?: any;
};

export function SegmentedTabsGS<K extends string = DefaultTabKey>({
  tab,
  setTab,
  theme,
  items,
  disabled,
}: {
  tab: K;
  setTab: (k: K) => void;
  theme: any;
  items?: Array<SegmentedTabItem<K>>;
  disabled?: boolean;
}) {
  const defaultItems = useMemo<Array<SegmentedTabItem<DefaultTabKey>>>(
    () => [
      { key: 'active', label: 'Active', Icon: Truck },
      { key: 'history', label: 'History', Icon: History },
    ],
    [],
  );

  // If you pass custom items (offline/available), we use them.
  // If not, we fall back to Active/History.
  const tabs = (items?.length ? items : (defaultItems as any)) as Array<
    SegmentedTabItem<K>
  >;

  return (
    <View style={{ marginTop: theme.space[4], width: '100%' }}>
      <Box>
        <HStack
          bg={theme.colors.surface2}
          borderColor={theme.colors.border}
          borderWidth={1}
          rounded={theme.radius.pill}
          p={4}
          alignItems="center"
        >
          {tabs.map((it, idx) => {
            const active = tab === it.key;
            const Icon = it.Icon;

            return (
              <React.Fragment key={String(it.key)}>
                <GSPressable
                  disabled={disabled}
                  onPress={() => setTab(it.key)}
                  style={{
                    flex: 1,
                    borderRadius: theme.radius.pill,
                    paddingVertical: theme.space[2],
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: active
                      ? theme.colors.surface
                      : 'transparent',
                    ...(active ? theme.shadow.card : {}),
                    opacity: disabled ? 0.6 : 1,
                  }}
                >
                  <HStack alignItems="center" justifyContent="center">
                    {Icon ? (
                      <>
                        <Icon
                          size={16}
                          strokeWidth={2.8}
                          color={
                            active ? theme.colors.text : theme.colors.textMuted
                          }
                        />
                        <Box style={{ width: theme.space[2] }} />
                      </>
                    ) : null}

                    <TText
                      align="center"
                      color={
                        active ? theme.colors.text : theme.colors.textMuted
                      }
                      variant="caption"
                      weight={active ? 'bold' : 'medium'}
                    >
                      {it.label}
                    </TText>
                  </HStack>
                </GSPressable>

                {idx < tabs.length - 1 ? (
                  <Box
                    w={1}
                    alignSelf="stretch"
                    bg={theme.colors.border}
                    opacity={0.6}
                    my={6}
                  />
                ) : null}
              </React.Fragment>
            );
          })}
        </HStack>
      </Box>
    </View>
  );
}

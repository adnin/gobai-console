import React from 'react';
import { StyleSheet } from 'react-native';

import { Box, HStack, VStack } from '@gluestack-ui/themed';

import { useAppTheme } from '@/src/ui/themed';
import GSText from '@/src/ui/gs/GSText';

export type GSBannerTone = 'error' | 'success' | 'warning' | 'info' | 'neutral';

export default function GSBanner({
  left,
  message,
  right,
  style,
  title,
  tone = 'neutral',
}: {
  message: string;
  title?: string;
  tone?: GSBannerTone;
  left?: React.ReactNode;
  right?: React.ReactNode;
  style?: any;
}) {
  const theme = useAppTheme();

  const palette =
    tone === 'error'
      ? { bg: 'rgba(239, 68, 68, 0.10)', border: 'rgba(239, 68, 68, 0.28)' }
      : tone === 'success'
        ? { bg: 'rgba(34, 197, 94, 0.10)', border: 'rgba(34, 197, 94, 0.28)' }
        : tone === 'warning'
          ? {
              bg: 'rgba(245, 158, 11, 0.10)',
              border: 'rgba(245, 158, 11, 0.28)',
            }
          : tone === 'info'
            ? {
                bg: 'rgba(59, 130, 246, 0.10)',
                border: 'rgba(59, 130, 246, 0.28)',
              }
            : {
                bg: theme.colors.surface2 ?? theme.colors.surface,
                border: theme.colors.border,
              };

  return (
    <Box
      bg={palette.bg as any}
      borderColor={palette.border as any}
      borderWidth={StyleSheet.hairlineWidth}
      px={theme.space[3]}
      py={theme.space[3]}
      rounded={theme.radius.xl}
      style={style}
    >
      <HStack
        alignItems="center"
        justifyContent="space-between"
        gap={theme.space[2]}
      >
        <HStack alignItems="center" flex={1} gap={theme.space[2]}>
          {left ? <Box>{left}</Box> : null}

          <VStack flex={1} gap={2}>
            {title ? (
              <GSText variant="caption" weight="bold">
                {title}
              </GSText>
            ) : null}
            <GSText variant="caption" style={{ flex: 1 }}>
              {message}
            </GSText>
          </VStack>
        </HStack>
        {right ? <Box>{right}</Box> : null}
      </HStack>
    </Box>
  );
}

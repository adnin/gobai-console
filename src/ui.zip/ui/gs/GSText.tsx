// src/ui/gs/GSText.tsx
import { useAppTheme } from '@/src/ui/themed';
import { Text } from '@gluestack-ui/themed';
import React from 'react';

export type GSTextVariant =
  | 'title'
  | 'subtitle'
  | 'body'
  | 'caption'
  | 'badge'
  | 'muted';

export type GSTextWeight = 'regular' | 'medium' | 'bold';

export type GSTextAlign = 'auto' | 'left' | 'center' | 'right' | 'justify';

function fontSizeForVariant(theme: any, variant: GSTextVariant) {
  switch (variant) {
    case 'title':
      // Apple-like hierarchy (boring on purpose): clear title, calm body
      return theme.font?.size?.xl ?? 20;
    case 'subtitle':
      return theme.font?.size?.lg ?? 16;
    case 'body':
      return theme.font?.size?.md ?? 14;
    case 'muted':
      return theme.font?.size?.xs ?? 12;
    case 'badge':
      return 12;
    case 'caption':
      return theme.font?.size?.xs ?? 12;
    default:
      return theme.font?.size?.md ?? 14;
  }
}

function lineHeightForVariant(theme: any, variant: GSTextVariant) {
  // Prefer theme lineHeights if you have them; fall back to clean enterprise defaults
  const lh = theme.font?.lineHeight ?? {};
  switch (variant) {
    case 'title':
      return lh.xl ?? 26;
    case 'subtitle':
      return lh.lg ?? 22;
    case 'body':
      return lh.md ?? 20;
    case 'muted':
      return lh.sm ?? 18;
    case 'badge':
      return lh.xs ?? 16;
    case 'caption':
      return lh.xs ?? 16;
    default:
      return lh.md ?? 20;
  }
}

function fontWeightForWeight(theme: any, weight?: GSTextWeight) {
  if (weight === 'bold') {
    // calmer hierarchy: use 700 instead of 800
    return String(theme.font?.weight?.bold ?? '700');
  }
  if (weight === 'medium') {
    return String(theme.font?.weight?.medium ?? '600');
  }
  return String(theme.font?.weight?.regular ?? '500');
}

export default function GSText({
  children,
  color,
  numberOfLines,
  style,
  variant = 'body',
  weight,
  align,
}: {
  children: React.ReactNode;
  variant?: GSTextVariant;
  weight?: GSTextWeight;
  color?: string;
  numberOfLines?: number;
  style?: any;
  align?: GSTextAlign;
}) {
  const theme = useAppTheme();

  // ✅ Muted auto-color unless a custom color is provided
  const resolvedColor =
    color ??
    (variant === 'muted' || variant === 'caption'
      ? theme.colors.textMuted
      : theme.colors.text);

  const alignStyle = align ? { textAlign: align } : {};

  return (
    <Text
      color={resolvedColor as any}
      fontSize={fontSizeForVariant(theme, variant)}
      fontWeight={fontWeightForWeight(theme, weight)}
      // ✅ Better readability & consistent density
      style={[
        alignStyle,
        {
          lineHeight: lineHeightForVariant(theme, variant),
          includeFontPadding: false,
        },
        style,
      ]}
      numberOfLines={numberOfLines}
    >
      {children}
    </Text>
  );
}

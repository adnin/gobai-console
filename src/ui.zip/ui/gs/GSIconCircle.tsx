import React from 'react';
import { StyleSheet } from 'react-native';

import { Box } from '@gluestack-ui/themed';

import { useAppTheme } from '@/src/ui/themed';

export default function GSIconCircle({
  children,
  size,
  style,
}: {
  children: React.ReactNode;
  size?: number;
  style?: any;
}) {
  const theme = useAppTheme();
  const s = size ?? theme.space[9];

  return (
    <Box
      alignItems="center"
      justifyContent="center"
      bg={theme.colors.surface2 as any}
      borderColor={theme.colors.border as any}
      borderWidth={StyleSheet.hairlineWidth}
      rounded={theme.radius.lg}
      h={s}
      w={s}
      style={style}
    >
      {children}
    </Box>
  );
}

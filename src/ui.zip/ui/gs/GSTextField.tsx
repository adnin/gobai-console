// ✅ Fixed GSTextField: supports `rightIcon` prop (maps to `right`)
// - Keeps existing `left/right` API
// - Adds `leftIcon/rightIcon` aliases so old/new screens won’t error

import GSText from '@/src/ui/gs/GSText';
import { useAppTheme } from '@/src/ui/themed';
import {
  HStack,
  Input,
  InputField,
  InputSlot,
  VStack,
} from '@gluestack-ui/themed';
import React, { forwardRef, useImperativeHandle, useMemo, useRef } from 'react';
import { StyleSheet, type TextInput } from 'react-native';

type Props = {
  label: string;
  value: string;
  onChangeText: (t: string) => void;

  placeholder?: string;
  helperText?: string;

  editable?: boolean;

  secureTextEntry?: boolean;
  keyboardType?: any;
  autoCapitalize?: any;
  autoCorrect?: boolean;

  returnKeyType?: any;
  blurOnSubmit?: boolean;
  onSubmitEditing?: () => void;

  // ✅ preferred slots
  left?: React.ReactNode;
  right?: React.ReactNode;

  // ✅ aliases (so screens using rightIcon/leftIcon compile)
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;

  /** Optional wrapper style */
  style?: any;
};

const GSTextField = forwardRef<TextInput, Props>(function GSTextField(
  {
    autoCapitalize,
    autoCorrect,
    blurOnSubmit,
    editable = true,
    helperText,
    keyboardType,
    label,
    left,
    leftIcon,
    onChangeText,
    onSubmitEditing,
    placeholder,
    returnKeyType,
    right,
    rightIcon,
    secureTextEntry,
    style,
    value,
  },
  ref,
) {
  const theme = useAppTheme();

  const nativeRef = useRef<TextInput>(null);
  useImperativeHandle(ref, () => nativeRef.current as TextInput, []);

  const inputH = theme.sizes?.inputH ?? 52;
  const radius = theme.radius?.xl ?? 16;

  const resolvedLeft = useMemo(
    () => left ?? leftIcon ?? null,
    [left, leftIcon],
  );
  const resolvedRight = useMemo(
    () => right ?? rightIcon ?? null,
    [right, rightIcon],
  );

  return (
    <VStack style={style}>
      <GSText
        color={theme.colors.textMuted}
        variant="caption"
        weight="bold"
        style={{ marginBottom: theme.space[2], letterSpacing: 0.2 }}
      >
        {label}
      </GSText>

      <Input
        bg={theme.colors.surface as any}
        borderColor={theme.colors.border as any}
        borderWidth={StyleSheet.hairlineWidth}
        h={inputH}
        px={theme.space[4]}
        rounded={radius}
        sx={{ opacity: editable ? 1 : 0.75 }}
        style={{
          shadowColor: '#000',
          shadowOpacity: 0.035,
          shadowRadius: 12,
          shadowOffset: { width: 0, height: 8 },
        }}
      >
        <HStack alignItems="center" flex={1} gap={theme.space[2]}>
          {resolvedLeft ? <InputSlot>{resolvedLeft}</InputSlot> : null}

          <InputField
            // ✅ Gluestack ref typing mismatch workaround
            ref={(inst: any) => {
              nativeRef.current = inst as TextInput;
            }}
            autoCapitalize={autoCapitalize}
            autoCorrect={autoCorrect}
            blurOnSubmit={blurOnSubmit}
            editable={editable}
            keyboardType={keyboardType}
            placeholder={placeholder}
            returnKeyType={returnKeyType}
            secureTextEntry={secureTextEntry}
            value={value}
            onChangeText={onChangeText}
            onSubmitEditing={onSubmitEditing}
            style={{
              color: theme.colors.text,
              flex: 1,
              fontSize: theme.font?.size?.md ?? 16,
              includeFontPadding: false,
              paddingVertical: 0,
            }}
          />

          {resolvedRight ? <InputSlot>{resolvedRight}</InputSlot> : null}
        </HStack>
      </Input>

      {helperText ? (
        <GSText
          color={theme.colors.textMuted}
          variant="caption"
          style={{ marginTop: theme.space[2] }}
        >
          {helperText}
        </GSText>
      ) : null}
    </VStack>
  );
});

export default GSTextField;

import { useAppTheme } from '@/src/ui/themed';
import {
  ButtonText,
  Button as GSButtonBase,
  HStack,
  Spinner,
} from '@gluestack-ui/themed';
import React from 'react';
import { StyleSheet } from 'react-native';

// Allowed button variants. A 'subtle' variant has been added to support
// quieter secondary actions (e.g. refresh buttons) per the design system.
export type GSButtonVariant =
  | 'primary'
  | 'secondary'
  | 'danger'
  | 'ghost'
  | 'subtle';
export type GSButtonSize = 'sm' | 'md' | 'lg';

export default function GSButton({
  disabled,
  leftIcon,
  loading,
  onPress,
  rightIcon,
  style,
  size = 'md',
  title,
  variant = 'primary',
}: {
  title: string;
  onPress?: () => void;
  disabled?: boolean;
  loading?: boolean;
  variant?: GSButtonVariant;
  size?: GSButtonSize;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  style?: any;
}) {
  const theme = useAppTheme();

  const h =
    size === 'sm'
      ? Math.max(36, theme.sizes?.buttonH ? theme.sizes.buttonH - 8 : 36)
      : size === 'lg'
        ? Math.max(52, theme.sizes?.buttonH ? theme.sizes.buttonH + 8 : 52)
        : (theme.sizes?.buttonH ?? 44);

  const px =
    size === 'sm'
      ? theme.space[4]
      : size === 'lg'
        ? theme.space[6]
        : theme.space[5];

  // ✅ Keep primary buttons visibly "Grab green".
  // Some themes set colors.primary to a light value, which can make white text
  // unreadable ("white on white"). Prefer brand green first.
  const brandGreen = (theme as any)?.brand?.green?.[500] ?? '#00b14f';

  const bg =
    variant === 'danger'
      ? theme.colors.danger
      : variant === 'secondary'
        ? theme.colors.surface2
        : variant === 'ghost'
          ? 'transparent'
          : variant === 'subtle'
            ? theme.colors.surface2
            : brandGreen;

  const borderColor =
    variant === 'secondary'
      ? theme.colors.border
      : variant === 'ghost'
        ? 'transparent'
        : variant === 'subtle'
          ? theme.colors.border
          : 'transparent';

  const textColor =
    variant === 'secondary'
      ? theme.colors.text
      : variant === 'ghost'
        ? brandGreen
        : variant === 'subtle'
          ? theme.colors.text
          : '#fff';

  return (
    <GSButtonBase
      accessibilityRole="button"
      action={variant === 'danger' ? 'negative' : 'primary'}
      bg={bg}
      borderColor={borderColor}
      borderWidth={
        variant === 'secondary' || variant === 'subtle'
          ? StyleSheet.hairlineWidth
          : 0
      }
      disabled={disabled || loading}
      h={h}
      onPress={onPress}
      px={px}
      rounded={theme.radius.pill}
      style={style}
      sx={{
        opacity: disabled || loading ? 0.6 : 1,
      }}
    >
      <HStack alignItems="center" gap={theme.space[2]}>
        {loading ? <Spinner color={textColor as any} size="small" /> : leftIcon}
        <ButtonText
          color={textColor as any}
          fontSize={size === 'sm' ? 13 : 15}
          fontWeight="600"
          includeFontPadding={false}
        >
          {title}
        </ButtonText>
        {!loading ? rightIcon : null}
      </HStack>
    </GSButtonBase>
  );
}

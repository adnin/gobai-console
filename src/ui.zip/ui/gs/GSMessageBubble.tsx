// src/ui/gs/GSMessageBubble.tsx
import GSText from '@/src/ui/gs/GSText';
import { useAppTheme } from '@/src/ui/themed';
import { View } from 'react-native';

export default function GSMessageBubble({
  role,
  text,
  timestamp,
  status,
}: {
  role: 'user' | 'assistant' | 'system';
  text: string;
  timestamp?: string;
  status?: string;
}) {
  const theme = useAppTheme();
  const isUser = role === 'user';

  const textColor = isUser ? '#fff' : theme.colors.text;

  return (
    <View style={{ marginVertical: theme.space[2] }}>
      <View>
        <GSText variant="body" color={textColor}>
          {text}
        </GSText>
      </View>

      {timestamp || status ? (
        <View
          style={{
            flexDirection: 'row',
            justifyContent: isUser ? 'flex-end' : 'flex-start',
            marginTop: theme.space[1],
          }}
        >
          {status ? (
            <GSText variant="caption" color={theme.colors.textMuted}>
              {status}
            </GSText>
          ) : null}
          {timestamp ? (
            <GSText
              variant="caption"
              color={theme.colors.textMuted}
              style={{ marginLeft: status ? theme.space[2] : 0 }}
            >
              {timestamp}
            </GSText>
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

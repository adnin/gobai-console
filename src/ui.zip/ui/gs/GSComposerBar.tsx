// src/ui/gs/GSComposerBar.tsx
import GSText from '@/src/ui/gs/GSText';
import Button from '@/src/ui/gs/GSButton';
import { useAppTheme } from '@/src/ui/themed';
import { HStack, Input, InputField, VStack } from '@gluestack-ui/themed';
import React, { useMemo } from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import GSTypingIndicator from './GSTypingIndicator';

export default function GSComposerBar({
  value,
  onChangeText,
  onSend,
  placeholder = 'Type a message…',
  disabled,
  streaming,
  online = true,
  showLastSaved,
  lastSavedLabel,
}: {
  value: string;
  onChangeText: (t: string) => void;
  onSend: () => void;
  placeholder?: string;
  disabled?: boolean;
  streaming?: boolean;
  online?: boolean;
  showLastSaved?: boolean;
  lastSavedLabel?: string | null;
}) {
  const theme = useAppTheme();
  const canSend = useMemo(() => !disabled && online && value.trim().length > 0 && !streaming, [
    disabled,
    online,
    streaming,
    value,
  ]);

  return (
    <View
      style={{
        backgroundColor: theme.colors.bg,
        borderTopWidth: StyleSheet.hairlineWidth,
        borderTopColor: theme.colors.border,
        paddingTop: theme.space[2],
        paddingBottom: Platform.OS === 'ios' ? theme.space[3] : theme.space[2],
        paddingHorizontal: theme.space[4],
      }}
    >
      <VStack space="xs">
        <HStack space="sm" alignItems="flex-end">
          <Input
            flex={1}
            bg={theme.colors.surface as any}
            borderColor={theme.colors.border as any}
            borderWidth={StyleSheet.hairlineWidth}
            rounded={16 as any}
            px={theme.space[3]}
            py={theme.space[2]}
            style={{
              shadowColor: '#000',
              shadowOpacity: 0.035,
              shadowRadius: 10,
              shadowOffset: { width: 0, height: 6 },
            }}
          >
            <InputField
              value={value}
              onChangeText={onChangeText}
              placeholder={placeholder}
              multiline
              numberOfLines={3}
              style={{
                minHeight: 44,
                paddingVertical: 2,
                color: theme.colors.text,
              }}
              placeholderTextColor={theme.colors.textMuted}
              returnKeyType="send"
              blurOnSubmit={false}
              onSubmitEditing={() => {
                if (canSend) onSend();
              }}
            />
          </Input>

          <Button
            title={streaming ? '…' : 'Send'}
            variant="primary"
            onPress={onSend}
            disabled={!canSend}
          />
        </HStack>

        {(streaming || !online || (showLastSaved && lastSavedLabel)) ? (
          <HStack alignItems="center" justifyContent="space-between">
            <HStack alignItems="center" space="xs">
              {streaming ? <GSTypingIndicator /> : null}
              {!online ? (
                <GSText variant="caption" color={theme.colors.warning}>
                  Offline — will retry
                </GSText>
              ) : streaming ? (
                <GSText variant="caption" color={theme.colors.textMuted}>
                  Thinking…
                </GSText>
              ) : null}
            </HStack>

            {showLastSaved && lastSavedLabel ? (
              <GSText variant="caption" color={theme.colors.textMuted}>
                Saved {lastSavedLabel}
              </GSText>
            ) : null}
          </HStack>
        ) : null}
      </VStack>
    </View>
  );
}

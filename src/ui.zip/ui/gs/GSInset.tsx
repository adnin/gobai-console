import { useAppTheme } from '@/src/ui/themed';
import { memo } from 'react';
import {
  View,
  type StyleProp,
  type ViewProps,
  type ViewStyle,
} from 'react-native';

type RadiusKey = keyof ReturnType<typeof useAppTheme>['radius'];

type Props = ViewProps & {
  pad?: number; // uses theme.space[pad]
  radius?: RadiusKey; // uses theme.radius[radius]
  style?: StyleProp<ViewStyle>;
};

function nSpace(theme: any, idx?: number) {
  if (idx === undefined || idx === null) {
    return undefined;
  }
  return theme.space?.[idx] ?? idx;
}

export default memo(function GSInset({
  pad = 4,
  radius = 'xl',
  style,
  children,
  ...rest
}: Props) {
  const theme = useAppTheme();

  return (
    <View
      {...rest}
      style={[
        {
          padding: nSpace(theme, pad),
          borderRadius: theme.radius[radius] ?? theme.radius.xl,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
});

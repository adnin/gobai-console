import { useAppTheme } from '@/src/ui/themed';
import { Box } from '@gluestack-ui/themed';
import React, { memo, useMemo } from 'react';
import {
  Pressable,
  StyleSheet,
  type StyleProp,
  type ViewStyle,
} from 'react-native';

type Theme = ReturnType<typeof useAppTheme>;
type RadiusKey = keyof Theme['radius'];

export type GSCardTone =
  | 'neutral'
  | 'surface2'
  | 'primarySoft'
  | 'warningSoft'
  | 'dangerSoft'
  | 'successSoft';

type Props = {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;

  pad?: number;
  radius?: RadiusKey;

  tone?: GSCardTone;
  outlined?: boolean;
  borderless?: boolean;
  shadow?: 'none' | 'card' | 'floating';

  pressable?: boolean;
  disabled?: boolean;
  onPress?: () => void;
  accessibilityLabel?: string;
};

function space(theme: Theme, idx?: number) {
  if (idx === undefined || idx === null) {
    return undefined;
  }
  return (theme.space?.[idx] as any) ?? idx;
}

function resolveTone(theme: Theme, tone: GSCardTone) {
  switch (tone) {
    case 'surface2':
      return {
        bg: theme.colors.surface2,
        border: (theme.colors as any).cardBorder ?? theme.colors.border,
      };
    case 'primarySoft':
      return { bg: 'rgba(0,177,79,0.10)', border: 'rgba(0,177,79,0.18)' };
    case 'warningSoft':
      return { bg: 'rgba(245,158,11,0.10)', border: 'rgba(245,158,11,0.18)' };
    case 'dangerSoft':
      return { bg: 'rgba(239,68,68,0.08)', border: 'rgba(239,68,68,0.18)' };
    case 'successSoft':
      return { bg: 'rgba(34,197,94,0.10)', border: 'rgba(34,197,94,0.18)' };
    case 'neutral':
    default:
      return {
        bg: theme.colors.surface,
        border: (theme.colors as any).cardBorder ?? theme.colors.border,
      };
  }
}

function resolveShadow(theme: Theme, shadow: Props['shadow']) {
  if (shadow === 'none') {
    return null;
  }
  if (shadow === 'floating') {
    return theme.shadow?.floating ?? theme.shadow?.card;
  }
  return theme.shadow?.card;
}

export default memo(function GSCard({
  children,
  style,

  // ✅ make BDO-style the default everywhere
  pad = 3,
  radius = 'xl',

  tone = 'neutral',
  outlined = false,
  borderless = true,
  shadow = 'card',

  pressable = false,
  disabled,
  onPress,
  accessibilityLabel,
}: Props) {
  const theme = useAppTheme();

  const toneTokens = useMemo(() => resolveTone(theme, tone), [theme, tone]);
  const shadowStyle = useMemo(
    () => resolveShadow(theme, shadow),
    [theme, shadow],
  );

  const r = (theme.radius[radius] ?? theme.radius.xl) as any;

  const borderWidth = borderless ? 0 : outlined ? StyleSheet.hairlineWidth : 0;

  const inner = (
    <Box
      bg={toneTokens.bg as any}
      borderColor={toneTokens.border as any}
      borderWidth={borderWidth as any}
      rounded={r}
      style={[
        { overflow: 'hidden' }, // ✅ clips image corners cleanly
        pad !== undefined ? { padding: space(theme, pad) } : null,
      ]}
    >
      {children}
    </Box>
  );

  const card = (
    <Box rounded={r} style={[shadowStyle, style]}>
      {inner}
    </Box>
  );

  if (!pressable) {
    return card;
  }

  return (
    <Pressable
      accessibilityLabel={accessibilityLabel}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        { opacity: disabled ? 0.55 : pressed ? 0.96 : 1 },
      ]}
    >
      {card}
    </Pressable>
  );
});

// src/ui/gs/GSTopBar.tsx
import TText from '@/src/ui/gs/GSText';
import { useAppTheme } from '@/src/ui/themed';
import { useRouter } from 'expo-router';
import { ArrowLeft } from 'lucide-react-native';
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

export default function GSTopBar({
  title,
  subtitle,
  right,
  left,
  showBack,
  onBack,
}: {
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
  left?: React.ReactNode;
  showBack?: boolean;
  onBack?: () => void;
}) {
  const theme = useAppTheme();
  const router = useRouter();

  const canShowBack = !!showBack;

  return (
    <View
      style={{
        backgroundColor: theme.colors.bg ?? theme.colors.background,
        borderBottomColor: theme.colors.border,
        borderBottomWidth: StyleSheet.hairlineWidth,
        paddingHorizontal: theme.space[4],
        paddingTop: theme.space[3],
        paddingBottom: theme.space[3],
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        {/* Left */}
        <View style={{ width: 44, alignItems: 'flex-start' }}>
          {left ? (
            left
          ) : canShowBack ? (
            <Pressable
              accessibilityRole="button"
              hitSlop={10}
              onPress={() => (onBack ? onBack() : router.back())}
              style={({ pressed }) => [
                {
                  height: 40,
                  width: 40,
                  borderRadius: 999,
                  alignItems: 'center',
                  justifyContent: 'center',
                borderWidth: StyleSheet.hairlineWidth,
                  borderColor: theme.colors.border,
                  backgroundColor: theme.colors.surface,
                },
                pressed ? { opacity: 0.75 } : null,
              ]}
            >
              <ArrowLeft
                size={18}
                strokeWidth={2.6}
                color={theme.colors.text}
              />
            </Pressable>
          ) : null}
        </View>

        {/* Title/Sub */}
        <View style={{ flex: 1, minWidth: 0 }}>
          <TText numberOfLines={1} variant="subtitle" weight="medium">
            {title}
          </TText>
          {subtitle ? (
            <TText numberOfLines={1} variant="muted" style={{ marginTop: 2 }}>
              {subtitle}
            </TText>
          ) : null}
        </View>

        {/* Right */}
        <View style={{ marginLeft: theme.space[3] }}>{right}</View>
      </View>
    </View>
  );
}

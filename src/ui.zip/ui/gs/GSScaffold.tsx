// src/ui/gs/GSScaffold.tsx
import React from 'react';
import { ScrollView, View, type ViewStyle } from 'react-native';

import Screen from './GSScreen';

/**
 * Predictable layout primitive:
 * - optional top
 * - scrollable content
 * - fixed bottom area (composer / CTA)
 *
 * Backward compatible: does not replace any existing screen automatically.
 */
export default function GSScaffold({
  top,
  bottom,
  children,
  keyboardAvoiding = true,
  contentContainerStyle,
  scroll = true,
  screenStyle,
}: {
  top?: React.ReactNode;
  bottom?: React.ReactNode;
  children: React.ReactNode;
  keyboardAvoiding?: boolean;
  scroll?: boolean;
  contentContainerStyle?: ViewStyle;
  screenStyle?: ViewStyle;
}) {
  const body = scroll ? (
    <ScrollView
      keyboardShouldPersistTaps="handled"
      contentContainerStyle={[
        { flexGrow: 1 },
        contentContainerStyle,
        // If you pass `bottom`, you should also add paddingBottom in the caller.
      ]}
      style={{ flex: 1 }}
    >
      {children}
    </ScrollView>
  ) : (
    <View style={{ flex: 1 }}>{children}</View>
  );

  return (
    <Screen keyboardAvoiding={keyboardAvoiding} style={screenStyle} bottom={bottom}>
      <View style={{ flex: 1 }}>
        {top ? <View>{top}</View> : null}
        <View style={{ flex: 1 }}>{body}</View>
      </View>
    </Screen>
  );
}

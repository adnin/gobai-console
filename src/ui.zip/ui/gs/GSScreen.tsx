import React from 'react';

import { KeyboardAvoidingView, Platform, View, type ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useAppTheme } from '@/src/ui/themed';

type SafeAreaProps = React.ComponentProps<typeof SafeAreaView>;

type Props = SafeAreaProps & {
  children: React.ReactNode;
  /**
   * Backward-compatible enhancement:
   * - When true, wraps children in a KeyboardAvoidingView (iOS padding).
   * - Default false to preserve existing behavior.
   */
  keyboardAvoiding?: boolean;
  /**
   * Optional fixed bottom area (e.g. composer / primary CTA).
   * When set, you should add bottom padding to scroll content so it won't be hidden.
   */
  bottom?: React.ReactNode;
  /**
   * Optional container style for the main content area.
   * Useful when using `bottom` to keep layout predictable.
   */
  contentStyle?: ViewStyle;
};

export default function GSScreen({
  children,
  edges = ['top', 'bottom', 'left', 'right'],
  style,
  keyboardAvoiding = false,
  bottom,
  contentStyle,
  ...rest
}: Props) {
  const theme = useAppTheme();

  const body = keyboardAvoiding ? (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{ flex: 1 }}
    >
      <View style={[{ flex: 1 }, contentStyle]}>{children}</View>
    </KeyboardAvoidingView>
  ) : (
    <View style={[{ flex: 1 }, contentStyle]}>{children}</View>
  );

  return (
    <SafeAreaView
      edges={edges}
      style={[{ flex: 1, backgroundColor: theme.colors.bg }, style]}
      {...rest}
    >
      <View style={{ flex: 1 }}>
        {body}
        {bottom ? (
          <View
            style={{
              position: 'absolute',
              left: 0,
              right: 0,
              bottom: 0,
            }}
          >
            {bottom}
          </View>
        ) : null}
      </View>
    </SafeAreaView>
  );
}

import React from 'react';
import { StyleSheet } from 'react-native';

import { Box } from '@gluestack-ui/themed';

import { useAppTheme } from '@/src/ui/themed';

export type GSPillTone = 'primary' | 'success' | 'warning' | 'danger' | 'neutral';

export default function GSPill({
  children,
  tone = 'neutral',
  style,
}: {
  children: React.ReactNode;
  tone?: GSPillTone;
  style?: any;
}) {
  const theme = useAppTheme();

  const bg =
    tone === 'primary'
      ? 'rgba(0,177,79,0.12)'
      : tone === 'success'
        ? 'rgba(34,197,94,0.12)'
        : tone === 'warning'
          ? 'rgba(245,158,11,0.12)'
          : tone === 'danger'
            ? 'rgba(239,68,68,0.10)'
            : theme.colors.surface2;

  const br =
    tone === 'primary'
      ? 'rgba(0,177,79,0.22)'
      : tone === 'success'
        ? 'rgba(34,197,94,0.22)'
        : tone === 'warning'
          ? 'rgba(245,158,11,0.22)'
          : tone === 'danger'
            ? 'rgba(239,68,68,0.20)'
            : theme.colors.border;

  return (
    <Box
      alignItems="center"
      borderColor={br as any}
      borderWidth={StyleSheet.hairlineWidth}
      bg={bg as any}
      flexDirection="row"
      px={theme.space[3]}
      py={theme.space[1]}
      rounded={theme.radius.pill}
      style={style}
    >
      {children}
    </Box>
  );
}

import React from 'react';
import { ActivityIndicator, Pressable, TextInput, View } from 'react-native';
import Text from '@/src/ui/Text';
import { useAppTheme } from '@/src/ui/themed';

type ActionState = 'approve' | 'reject' | null;

export type ApprovalCardProps = {
  title: string;
  subtitle?: string;
  amountLabel?: string;
  amountValue?: string;

  badges?: Array<{ label: string; tone?: 'neutral' | 'good' | 'warn' | 'bad' }>;

  /** Optional custom content (details, previews, etc.) */
  children?: React.ReactNode;

  /** Optional comment box (used for rejects, but can be used always) */
  noteLabel?: string;
  notePlaceholder?: string;
  noteValue?: string;
  onChangeNote?: (v: string) => void;
  requireNoteOnReject?: boolean;

  approveLabel?: string;
  rejectLabel?: string;
  disableApprove?: boolean;
  disableReject?: boolean;

  loadingAction?: ActionState;

  onApprove?: () => void;
  onReject?: () => void;

  /** Optional extra actions (e.g., pop out) */
  headerRight?: React.ReactNode;

  /** For list/modal surfaces */
  styleVariant?: 'sheet' | 'card';
};

function toneStyles(tone: NonNullable<ApprovalCardProps['badges']>[number]['tone']) {
  switch (tone) {
    case 'good':
      return { bg: '#ecfdf5', border: 'rgba(0,177,79,0.25)', text: '#047857' };
    case 'warn':
      return { bg: '#fffbeb', border: 'rgba(245,158,11,0.25)', text: '#92400e' };
    case 'bad':
      return { bg: '#fef2f2', border: 'rgba(239,68,68,0.25)', text: '#b91c1c' };
    default:
      return { bg: '#f8fafc', border: '#e5e7eb', text: '#334155' };
  }
}

function Badge({
  label,
  tone = 'neutral',
}: {
  label: string;
  tone?: 'neutral' | 'good' | 'warn' | 'bad';
}) {
  const t = toneStyles(tone);
  const theme = useAppTheme();
  return (
    <View
      style={{
        backgroundColor: t.bg,
        borderColor: t.border,
        borderWidth: 1,
        borderRadius: 999,
        paddingHorizontal: 10,
        paddingVertical: 6,
        marginRight: 8,
        marginBottom: 8,
      }}
    >
      <Text
        style={{
          fontSize: 11,
          fontWeight: theme.font.weight.extrabold,
          color: t.text,
        }}
      >
        {label}
      </Text>
    </View>
  );
}

export default function ApprovalCard(props: ApprovalCardProps) {
  const theme = useAppTheme();

  const {
    title,
    subtitle,
    amountLabel,
    amountValue,
    badges,
    children,
    noteLabel = 'Comment',
    notePlaceholder = 'Add a note (required on reject)…',
    noteValue,
    onChangeNote,
    requireNoteOnReject = false,
    approveLabel = 'Approve',
    rejectLabel = 'Reject',
    disableApprove,
    disableReject,
    loadingAction,
    onApprove,
    onReject,
    headerRight,
    styleVariant = 'sheet',
  } = props;

  const canTypeNote = typeof onChangeNote === 'function';
  const noteTooShort =
    requireNoteOnReject && canTypeNote ? String(noteValue ?? '').trim().length < 2 : false;

  const surfaceRadius = styleVariant === 'sheet' ? 34 : 28;

  return (
    <View
      style={{
        backgroundColor: theme.colors.surface,
        borderRadius: surfaceRadius,
        borderWidth: 1,
        borderColor: '#eef2f7',
        paddingHorizontal: theme.space[4],
        paddingTop: theme.space[3],
        paddingBottom: theme.space[4],
      }}
    >
      {/* Header */}
      <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
        <View style={{ flex: 1, paddingRight: theme.space[2] }}>
          <Text style={{ fontSize: 13, color: theme.brand.gray[500], marginBottom: 4 }}>
            {title}
          </Text>
          {subtitle ? (
            <Text
              style={{
                fontSize: 18,
                fontWeight: theme.font.weight.extrabold,
                color: theme.colors.text,
              }}
              numberOfLines={2}
            >
              {subtitle}
            </Text>
          ) : null}
        </View>

        {headerRight ? <View style={{ marginLeft: theme.space[2] }}>{headerRight}</View> : null}
      </View>

      {/* Amount */}
      {amountValue ? (
        <View
          style={{
            marginTop: theme.space[3],
            padding: theme.space[4],
            borderRadius: 26,
            borderWidth: 1,
            borderColor: '#eef2f7',
            backgroundColor: '#f8fafc',
          }}
        >
          {amountLabel ? (
            <Text style={{ fontSize: 11, color: theme.brand.gray[500] }}>{amountLabel}</Text>
          ) : null}
          <Text
            style={{
              fontSize: 30,
              fontWeight: theme.font.weight.extrabold,
              color: theme.colors.text,
              marginTop: 2,
            }}
          >
            {amountValue}
          </Text>

          {badges?.length ? (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: theme.space[3] }}>
              {badges.map((b, i) => (
                <Badge key={`${b.label}-${i}`} label={b.label} tone={b.tone} />
              ))}
            </View>
          ) : null}
        </View>
      ) : badges?.length ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: theme.space[3] }}>
          {badges.map((b, i) => (
            <Badge key={`${b.label}-${i}`} label={b.label} tone={b.tone} />
          ))}
        </View>
      ) : null}

      {/* Body */}
      {children ? <View style={{ marginTop: theme.space[3] }}>{children}</View> : null}

      {/* Note */}
      {canTypeNote ? (
        <View style={{ marginTop: theme.space[3] }}>
          <Text style={{ fontSize: 12, color: theme.brand.gray[600] }}>{noteLabel}</Text>
          <TextInput
            placeholder={notePlaceholder}
            placeholderTextColor={theme.brand.gray[400]}
            value={noteValue ?? ''}
            onChangeText={onChangeNote}
            multiline
            style={{
              marginTop: 8,
              minHeight: 44,
              borderWidth: 1,
              borderColor: noteTooShort ? 'rgba(239,68,68,0.35)' : '#e5e7eb',
              borderRadius: 16,
              paddingHorizontal: 12,
              paddingVertical: 10,
              color: theme.colors.text,
              backgroundColor: '#fff',
              fontSize: 12,
            }}
          />
          {noteTooShort ? (
            <Text style={{ marginTop: 6, fontSize: 11, color: '#b91c1c' }}>
              Please add a short reason before rejecting.
            </Text>
          ) : null}
        </View>
      ) : null}

      {/* Actions */}
      {(onApprove || onReject) ? (
        <View style={{ marginTop: theme.space[4] }}>
          {onApprove ? (
            <Pressable
              onPress={onApprove}
              disabled={!!disableApprove || loadingAction !== null}
              style={{
                height: 48,
                borderRadius: 999,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor:
                  !!disableApprove || loadingAction !== null ? '#cbd5e1' : theme.brand.green[500],
              }}
            >
              {loadingAction === 'approve' ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text
                  style={{
                    color: '#fff',
                    fontSize: 13,
                    fontWeight: theme.font.weight.extrabold,
                  }}
                >
                  {approveLabel}
                </Text>
              )}
            </Pressable>
          ) : null}

          {onReject ? (
            <Pressable
              onPress={onReject}
              disabled={!!disableReject || loadingAction !== null || noteTooShort}
              style={{
                marginTop: 12,
                height: 48,
                borderRadius: 999,
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: 1,
                borderColor: 'rgba(239,68,68,0.20)',
                backgroundColor:
                  !!disableReject || loadingAction !== null ? '#f1f5f9' : '#fee2e2',
              }}
            >
              {loadingAction === 'reject' ? (
                <ActivityIndicator color="#b91c1c" />
              ) : (
                <Text
                  style={{
                    color: '#b91c1c',
                    fontSize: 13,
                    fontWeight: theme.font.weight.extrabold,
                  }}
                >
                  {rejectLabel}
                </Text>
              )}
            </Pressable>
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

import { useCallback, useMemo } from 'react';
import { useTheme } from 'styled-components/native';

import { sx as sxRaw } from '@/src/design/sx';

/**
 * Centralized theme helpers (enterprise standard):
 * - Keep hooks inside React components only
 * - Avoid prop-drilling theme
 * - Provide a typed Theme + memoized style factories
 */

export const useAppTheme = useTheme;

export type Theme = ReturnType<typeof useTheme>;

export function useSx() {
  const theme = useAppTheme();
  const sx = useCallback((classList?: string) => sxRaw(theme, classList), [theme]);
  return { sx, theme };
}

export function useThemedStyles<T>(makeStyles: (theme: Theme) => T) {
  const theme = useAppTheme();
  const styles = useMemo(() => makeStyles(theme), [makeStyles, theme]);
  return { styles, theme };
}

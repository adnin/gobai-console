// src/ui/home/HomePromoHero.tsx
// ✅ Enterprise polish: deeper teal hero + soft brand glows + frosted logo badge
// ✅ Logic unchanged

import TText from '@/src/ui/gs/GSText';
import { Image } from 'expo-image';
import { Sparkles } from 'lucide-react-native';
import React, { memo, useEffect, useMemo } from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  Easing,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSpring,
  withTiming,
} from 'react-native-reanimated';

/* ------------------------------ helpers ------------------------------ */

function formatGold(v?: number) {
  const n = Number(v ?? 0);
  try {
    return new Intl.NumberFormat(undefined, {
      maximumFractionDigits: 0,
    }).format(n);
  } catch {
    return String(Math.round(n));
  }
}

function heroTextStyles(theme: any) {
  const ios = Platform.OS === 'ios';
  const titleSize = ios ? 34 : 26;
  const subSize = ios ? 17 : 15;

  return StyleSheet.create({
    textWrap: { maxWidth: 520 },
    heroSub: {
      fontSize: subSize,
      lineHeight: Math.round(subSize * 1.35),
      letterSpacing: ios ? -0.2 : 0,
      // calmer white so it feels premium on richer background
      color: 'rgba(255,255,255,0.82)',
    },
    heroTitle: {
      marginTop: 4,
      fontSize: titleSize,
      lineHeight: Math.round(titleSize * 1.12),
      letterSpacing: ios ? -0.6 : -0.3,
      color: 'rgba(255,255,255,0.98)',
    },
  });
}

/* ------------------------------ press spring ------------------------------ */

function GesturePressSpring({
  accessibilityLabel,
  children,
  disabled,
  onPress,
  style,
}: {
  accessibilityLabel?: string;
  children: React.ReactNode;
  disabled?: boolean;
  onPress: () => void;
  style?: any;
}) {
  const pressed = useSharedValue(0);

  const aStyle = useAnimatedStyle(() => {
    const s = withSpring(pressed.value ? 0.985 : 1, {
      damping: 18,
      stiffness: 260,
      mass: 0.7,
    });
    const o = pressed.value ? 0.96 : 1;
    return { transform: [{ scale: s }], opacity: o };
  }, []);

  const tap = useMemo(() => {
    return Gesture.Tap()
      .enabled(!disabled)
      .onBegin(() => (pressed.value = 1))
      .onFinalize(() => (pressed.value = 0))
      .onEnd(() => runOnJS(onPress)());
  }, [disabled, onPress, pressed]);

  return (
    <GestureDetector gesture={tap}>
      <Animated.View
        accessibilityLabel={accessibilityLabel}
        style={[style, aStyle]}
      >
        {children}
      </Animated.View>
    </GestureDetector>
  );
}

/* ------------------------------ GoldValue (outside render) ------------------------------ */

const GoldValue = memo(function GoldValue({
  theme,
  loading,
  value,
}: {
  theme: any;
  loading: boolean;
  value: number;
}) {
  const x = useSharedValue(-120);

  useEffect(() => {
    x.value = withRepeat(
      withTiming(240, { duration: 1200, easing: Easing.inOut(Easing.quad) }),
      -1,
      false,
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const shineStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: x.value }, { rotate: '-16deg' }],
    opacity: 0.9,
  }));

  const goldSoft = theme?.colors?.gold?.soft ?? 'rgba(245,158,11,0.16)';
  const goldBorder = theme?.colors?.gold?.border ?? 'rgba(245,158,11,0.22)';
  const goldText = theme?.colors?.gold?.text ?? '#8A5A00';

  return (
    <View
      style={{
        marginLeft: 10,
        borderRadius: theme.radius.lg,
        borderWidth: 1,
        borderColor: goldBorder,
        backgroundColor: goldSoft,
        paddingHorizontal: 10,
        paddingVertical: 6,
        overflow: 'hidden',
      }}
    >
      <View
        style={{
          position: 'absolute',
          right: -26,
          top: -26,
          width: 72,
          height: 72,
          borderRadius: 999,
          backgroundColor: 'rgba(245,158,11,0.22)',
        }}
      />

      <Animated.View
        style={[
          {
            position: 'absolute',
            top: -24,
            left: 0,
            width: 42,
            height: 90,
            backgroundColor: 'rgba(255,255,255,0.28)',
            borderRadius: 999,
          },
          shineStyle,
        ]}
      />

      <TText
        variant="body"
        weight="bold"
        style={{
          color: goldText,
          fontVariant: ['tabular-nums'] as any,
        }}
      >
        {loading ? '—' : formatGold(value)}
      </TText>
    </View>
  );
});

/* ------------------------------ Flat Full-Width Driver Status Strip ------------------------------ */

const DriverStatusStrip = memo(function DriverStatusStrip({
  theme,
  isBusy,
  isOnline,
  disabled,
  onToggle,
  insetX,
}: {
  theme: any;
  isBusy: boolean;
  isOnline: boolean;
  disabled?: boolean;
  onToggle?: () => void;
  insetX: number;
}) {
  const tone: 'success' | 'warning' | 'danger' = isBusy
    ? 'warning'
    : isOnline
      ? 'success'
      : 'danger';

  const statusLabel = isBusy ? 'On a job' : isOnline ? 'Online' : 'Offline';

  const tintBg =
    tone === 'warning'
      ? 'rgba(245,158,11,0.10)'
      : tone === 'success'
        ? 'rgba(34,197,94,0.10)'
        : 'rgba(239,68,68,0.08)';

  const dot =
    tone === 'warning'
      ? theme.colors.warning
      : tone === 'success'
        ? theme.colors.success
        : theme.colors.danger;

  const switchOn = isOnline && !isBusy;
  const trackW = 48;
  const trackH = 28;
  const knob = 24;

  const trackBg = disabled
    ? theme.colors.surface2
    : switchOn
      ? (theme.brand?.green?.[500] ?? theme.colors.primary)
      : theme.colors.surface2;

  const knobLeft = switchOn ? trackW - knob - 2 : 2;
  const canTap = !!onToggle && !disabled;

  const hairline = StyleSheet.hairlineWidth || 1;
  const borderCol = theme?.colors?.border ?? 'rgba(0,0,0,0.10)';

  return (
    <GesturePressSpring
      accessibilityLabel="Toggle driver status"
      disabled={!canTap}
      onPress={() => onToggle?.()}
      style={{ opacity: canTap ? 1 : 0.6 }}
    >
      <View
        style={{
          width: '100%',
          borderRadius: 0,
          backgroundColor: theme.colors.surface,
          borderTopWidth: hairline,
          borderBottomWidth: hairline,
          borderColor: borderCol,
          overflow: 'hidden',
        }}
      >
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: tintBg,
          }}
        />

        <View
          style={{
            paddingHorizontal: insetX,
            paddingVertical: theme.space[3],
            flexDirection: 'row',
            alignItems: 'center',
          }}
        >
          <View style={{ flex: 1, minWidth: 0, paddingRight: theme.space[3] }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View
                style={{
                  width: 9,
                  height: 9,
                  borderRadius: 999,
                  backgroundColor: dot,
                  marginRight: theme.space[2],
                }}
              />

              <TText
                variant="body"
                weight="medium"
                numberOfLines={1}
                style={{ color: theme.colors.text }}
              >
                {statusLabel}
              </TText>

              {!disabled && !isBusy ? (
                <View
                  style={{
                    marginLeft: theme.space[2],
                    paddingHorizontal: 9,
                    paddingVertical: 5,
                    borderRadius: 999,
                    borderWidth: hairline,
                    borderColor: 'rgba(255,255,255,0.35)',
                    backgroundColor: 'rgba(255,255,255,0.22)',
                  }}
                >
                  <TText
                    variant="badge"
                    weight="medium"
                    style={{ color: theme.colors.text }}
                  >
                    Tap
                  </TText>
                </View>
              ) : null}
            </View>

            <TText
              variant="caption"
              color={theme.colors.textMuted}
              numberOfLines={1}
              style={{ marginTop: 6 }}
            >
              {isBusy
                ? 'Busy • offers locked'
                : isOnline
                  ? 'Receiving offers'
                  : 'Not receiving offers'}
            </TText>
          </View>

          <View style={{ alignItems: 'flex-end' }}>
            <View
              style={{
                width: trackW,
                height: trackH,
                borderRadius: 999,
                backgroundColor: trackBg,
                borderWidth: hairline,
                borderColor: 'rgba(0,0,0,0.10)',
                padding: 1,
                justifyContent: 'center',
              }}
            >
              <View
                style={{
                  width: knob,
                  height: knob,
                  borderRadius: 999,
                  backgroundColor: '#fff',
                  position: 'absolute',
                  left: knobLeft,
                  top: 1.5,
                  ...(Platform.OS === 'ios'
                    ? {
                        shadowColor: '#000',
                        shadowOffset: { height: 3, width: 0 },
                        shadowOpacity: 0.14,
                        shadowRadius: 6,
                      }
                    : {}),
                }}
              />
            </View>
          </View>
        </View>
      </View>
    </GesturePressSpring>
  );
});

/* ------------------------------ main component ------------------------------ */

export const HomePromoHero = memo(function HomePromoHero({
  theme,
  topInset,
  name,
  logoSource,

  isDriver,
  isBusy,
  isOnline,

  showDriverStatus,
  driverStatusDisabled,
  onToggleDriverStatus,

  walletLoading,
  walletPts,
  walletFrozen,
  walletOkForWork,
  onWalletPress,
  onTopupPress,

  showSearch,
  onSearchPress,
}: {
  theme: any;
  topInset: number;
  name: string;
  logoSource: any;

  isDriver: boolean;
  isBusy: boolean;
  isOnline: boolean;

  showDriverStatus?: boolean;
  driverStatusDisabled?: boolean;
  onToggleDriverStatus?: () => void;

  walletLoading: boolean;
  walletPts: number;
  walletFrozen: boolean;
  walletOkForWork: boolean;
  onWalletPress: () => void;
  onTopupPress: () => void;

  showSearch?: boolean;
  onSearchPress?: () => void;
}) {
  const ios = Platform.OS === 'ios';

  // --- hero (Frost, logo-first) ---
  const HERO_BASE = '#EAF6FF'; // clean ice
  const HERO_DEEP = '#D7F0FF'; // subtle depth
  const HERO_TEXT = '#072B3A'; // deep teal ink
  const HERO_SUB = 'rgba(7, 43, 58, 0.72)'; // calmer

  const padX = theme?.layout?.containerPadX ?? theme.space[4];

  const insetX = useMemo(() => {
    const base = padX;
    const extra = Platform.OS === 'android' ? theme.space[1] : 0;
    return base + extra;
  }, [padX, theme]);

  const t = useMemo(() => heroTextStyles(theme), [theme]);

  const walletHint = isDriver
    ? walletFrozen
      ? 'Frozen • contact support'
      : walletOkForWork
        ? 'Eligible for offers'
        : 'Need 50+ pts to accept'
    : 'Tap to view activity';

  const heroTitle = `Hi, ${name}`;
  const heroSub = isDriver ? 'Driver dashboard' : 'Welcome back';

  const showStatusStrip = !!(showDriverStatus ?? isDriver);

  return (
    <View
      style={{
        marginHorizontal: -insetX,
        marginTop: -topInset,
        // ✅ no paddingTop here
      }}
    >
      {/* hero */}
      <View
        style={{
          backgroundColor: HERO_BASE,
          paddingHorizontal: insetX,

          // ✅ hero bg now covers the status bar space
          paddingTop: topInset + (ios ? theme.space[3] : theme.space[2]),

          paddingBottom: ios ? theme.space[7] : theme.space[6],
          overflow: 'hidden',
        }}
      >
        {/* deep wash */}
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            backgroundColor: HERO_DEEP,
            opacity: 0.9,
          }}
        />

        {/* cyan glow (matches "BAI") */}
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            top: -90,
            right: -140,
            width: 420,
            height: 300,
            borderRadius: 999,
            backgroundColor: 'rgba(0, 170, 209, 0.22)', // #00AAD1
            transform: [{ rotate: '10deg' }],
          }}
        />

        {/* lime glow (matches wing accent) */}
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            top: -70,
            left: -120,
            width: 380,
            height: 240,
            borderRadius: 999,
            backgroundColor: 'rgba(153, 200, 18, 0.16)', // #99C812
            transform: [{ rotate: '-12deg' }],
          }}
        />

        {/* bottom separator (crisp enterprise finish) */}
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
            height: StyleSheet.hairlineWidth || 1,
            backgroundColor: 'rgba(0,0,0,0.06)',
          }}
        />

        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <View style={[t.textWrap, { flex: 1, paddingRight: theme.space[3] }]}>
            <TText
              variant="body"
              weight="medium"
              numberOfLines={1}
              style={[t.heroSub, { color: HERO_SUB }]}
            >
              {heroSub}
            </TText>

            <TText
              variant="body"
              weight="bold"
              numberOfLines={1}
              style={[t.heroTitle, { color: HERO_TEXT }]}
            >
              {heroTitle}
            </TText>
          </View>

          {/* logo badge (clean glass on light bg) */}
          <Image
            source={logoSource}
            contentFit="contain"
            style={{
              width: ios ? 92 : 112,
              height: ios ? 92 : 112,
              opacity: 1,
            }}
          />
        </View>
      </View>

      {/* Driver status (attached / full width) */}
      {isDriver && showStatusStrip ? (
        <View style={{ marginTop: -theme.space[5] }}>
          <DriverStatusStrip
            theme={theme}
            isBusy={isBusy}
            isOnline={isOnline}
            disabled={!!driverStatusDisabled}
            onToggle={onToggleDriverStatus}
            insetX={insetX}
          />
        </View>
      ) : null}

      {/* Wallet strip (full width, flat) */}
      <View
        style={{ marginTop: isDriver && showStatusStrip ? 0 : -theme.space[5] }}
      >
        <GesturePressSpring
          accessibilityLabel="Open wallet"
          onPress={onWalletPress}
        >
          <View
            style={{
              width: '100%',
              borderRadius: 0,
              backgroundColor: theme.colors.surface,
              borderTopWidth: StyleSheet.hairlineWidth || 1,
              borderBottomWidth: StyleSheet.hairlineWidth || 1,
              borderColor: theme?.colors?.border ?? 'rgba(0,0,0,0.10)',
              paddingHorizontal: insetX,
              paddingTop: theme.space[3],
              paddingBottom: theme.space[3],
              overflow: 'hidden',
            }}
          >
            <View
              style={{
                position: 'absolute',
                right: -46,
                top: -46,
                width: 160,
                height: 160,
                borderRadius: 999,
                backgroundColor: 'rgba(245, 158, 11, 0.10)',
              }}
            />

            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ flex: 1, minWidth: 0 }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                  }}
                >
                  <Sparkles
                    size={14}
                    strokeWidth={2.6}
                    color={theme.colors.gold?.base ?? 'rgba(245,158,11,1)'}
                  />

                  <TText
                    variant="body"
                    weight="medium"
                    style={{ marginLeft: 8 }}
                    numberOfLines={1}
                  >
                    Credits
                  </TText>

                  <View style={{ marginLeft: 10 }}>
                    <GoldValue
                      theme={theme}
                      loading={walletLoading}
                      value={walletPts}
                    />
                  </View>

                  {isDriver ? (
                    <View
                      style={{
                        marginLeft: theme.space[2],
                        marginTop: ios ? 0 : 2,
                        paddingHorizontal: 10,
                        paddingVertical: 6,
                        borderRadius: 999,
                        backgroundColor: walletFrozen
                          ? 'rgba(239,68,68,0.08)'
                          : walletOkForWork
                            ? 'rgba(34,197,94,0.08)'
                            : 'rgba(245,158,11,0.08)',
                        borderWidth: StyleSheet.hairlineWidth || 1,
                        borderColor: walletFrozen
                          ? 'rgba(239,68,68,0.14)'
                          : walletOkForWork
                            ? 'rgba(34,197,94,0.14)'
                            : 'rgba(245,158,11,0.14)',
                      }}
                    >
                      <TText
                        variant="badge"
                        weight="medium"
                        style={{
                          color: walletFrozen
                            ? theme.colors.danger
                            : walletOkForWork
                              ? theme.colors.success
                              : theme.colors.warning,
                        }}
                      >
                        {walletFrozen
                          ? 'Frozen'
                          : walletOkForWork
                            ? 'Eligible'
                            : 'Low'}
                      </TText>
                    </View>
                  ) : null}
                </View>

                <TText
                  variant="caption"
                  color={theme.colors.textMuted}
                  numberOfLines={1}
                  style={{ marginTop: 6 }}
                >
                  {walletHint}
                </TText>
              </View>

              <View style={{ marginLeft: theme.space[3] }}>
                <GesturePressSpring
                  accessibilityLabel="Top-up"
                  onPress={onTopupPress}
                >
                  <View
                    style={{
                      height: 40,
                      paddingHorizontal: 16,
                      borderRadius: 999,
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor:
                        theme.brand?.green?.[500] ?? theme.colors.primary,
                      borderWidth:
                        Platform.OS === 'ios'
                          ? StyleSheet.hairlineWidth || 1
                          : 0,
                      borderColor: 'rgba(255,255,255,0.35)',
                    }}
                  >
                    <TText
                      variant="body"
                      weight="medium"
                      style={{ color: '#fff' }}
                    >
                      Top-up
                    </TText>
                  </View>
                </GesturePressSpring>
              </View>
            </View>
          </View>
        </GesturePressSpring>
      </View>

      <View style={{ height: theme.space[3] }} />
    </View>
  );
});

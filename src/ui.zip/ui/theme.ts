// src/ui/theme.ts
import { PALETTE } from './palette.ts';

export const THEME = {
  colors: {
    bg: PALETTE.neutral.bg,
    border: PALETTE.neutral.border,
    danger: PALETTE.status.danger,
    info: PALETTE.status.info,
    muted: PALETTE.neutral.textMuted,

    primary: PALETTE.brand[500],
    primary600: PALETTE.brand[600],

    success: PALETTE.status.success,
    surface: PALETTE.neutral.card,
    text: PALETTE.neutral.text,
    warning: PALETTE.status.warning,
  },
} as const;

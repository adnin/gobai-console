// gluestack-config.ts
//
// This file defines a minimal set of design tokens for our application when
// using gluestack‑ui. gluestack‑ui uses a configuration object to define
// the design system (colors, spacing, radii, fonts, etc.). We map our
// existing brand palette into the token structure so that all components
// adopting gluestack automatically pick up our colours and sizes.

import { brand } from '@/src/design/brand';

// Our custom tokens are intentionally minimal. Only the colours and basic
// spacing/radius values used across the app are defined here. Additional
// tokens can be added as needed. gluestack-ui will merge these tokens
// with its own defaults when provided to the provider.
export const gluestackConfig = {
  tokens: {
    colors: {
      // Primary brand colours mapped across a 0–9 scale. gluestack uses a
      // numeric palette similar to Tailwind (0 lightest, 9 darkest).
      primary0: brand.green[50],
      primary1: brand.green[100],
      primary2: brand.green[200],
      primary3: brand.green[300],
      primary4: brand.green[400],
      primary5: brand.green[500],
      primary6: brand.green[600],
      primary7: brand.green[700],
      primary8: brand.green[800],
      primary9: brand.green[900],
      // Neutral surface colours used for backgrounds, cards and borders.
      // We re‑use our gray palette here.
      neutral0: brand.gray[50],
      neutral1: brand.gray[100],
      neutral2: brand.gray[200],
      neutral3: brand.gray[300],
      neutral4: brand.gray[400],
      neutral5: brand.gray[500],
      neutral6: brand.gray[600],
      neutral7: brand.gray[700],
      neutral8: brand.gray[800],
      neutral9: brand.gray[900],
      // Semantic colours for success, warning, error messages. gluestack
      // components such as Toast and Alerts will read these.
      success5: brand.green[500],
      warning5: brand.orange,
      danger5: brand.red,
    },
    radii: {
      sm: 4,
      md: 8,
      lg: 12,
      xl: 16,
      '2xl': 24,
      pill: 9999,
    },
    space: {
      0: 0,
      1: 4,
      2: 8,
      3: 12,
      4: 16,
      5: 20,
      6: 24,
      7: 28,
      8: 32,
      9: 36,
      10: 40,
    },
    fontSizes: {
      xs: 12,
      sm: 14,
      md: 16,
      lg: 18,
      xl: 20,
      '2xl': 24,
    },
  },
} as const;
﻿import Text from '@/src/ui/Text';
import { useAppTheme } from '@/src/ui/themed';
import React, { memo } from 'react';
import { Pressable, StyleSheet } from 'react-native';

import { ScrollView } from 'react-native-gesture-handler';
type AmountChipsProps = {
  disabled?: boolean;
  min?: number;
  onChange: (v: number) => void;
  presets?: Array<number>;
  value: number;
};

export const AmountChips = memo(function AmountChips({
  disabled = false,
  min = 50,
  onChange,
  presets = [50, 100, 200, 300, 500, 1000],
  value,
}: AmountChipsProps) {
  const theme = useAppTheme();

  return (
    <ScrollView
      contentContainerStyle={[styles.row, disabled && styles.rowDisabled]}
      horizontal
      scrollEnabled={!disabled}
      showsHorizontalScrollIndicator={false}
    >
      {presets.map((amt) => {
        const selected = amt === value;
        const chipDisabled = disabled || amt < min;

        return (
          <Pressable
            disabled={chipDisabled}
            key={amt}
            onPress={() => onChange(amt)}
            style={({ pressed }) => [
              styles.chip,
              {
                backgroundColor: selected
                  ? theme.brand.green[500]
                  : theme.colors.surface,
                borderColor: selected
                  ? theme.brand.green[500]
                  : theme.colors.border,
                opacity: chipDisabled ? 0.45 : pressed ? 0.9 : 1,
              },
            ]}
          >
            <Text
              style={{
                color: selected ? '#fff' : theme.colors.text,
                fontWeight: selected
                  ? theme.font.weight.medium
                  : theme.font.weight.medium,
              }}
            >
              ₱{amt.toFixed(0)}
            </Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
});

const styles = StyleSheet.create({
  chip: {
    alignItems: 'center',
    borderRadius: 999,
    borderWidth: 1,
    justifyContent: 'center',
    minWidth: 82,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  row: {
    gap: 10,
    paddingHorizontal: 2,
    paddingVertical: 6,
  },
  rowDisabled: {
    opacity: 0.9,
  },
});

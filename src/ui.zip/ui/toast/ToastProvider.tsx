﻿import Text from '@/src/ui/Text';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Animated, Platform, Pressable, StyleSheet } from 'react-native';
import { useTheme } from 'styled-components/native';

type ToastType = 'success' | 'error' | 'info';

type ToastPayload = {
  durationMs?: number;
  message: string;
  title?: string;
  type: ToastType;
};

type ToastApi = {
  error: (message: string, title?: string) => void;
  info: (message: string, title?: string) => void;
  show: (t: ToastPayload) => void;
  success: (message: string, title?: string) => void;
};

const ToastContext = createContext<ToastApi | null>(null);

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) {
    throw new Error('useToast must be used within <ToastProvider />');
  }
  return ctx;
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const theme = useTheme();

  // ✅ Animated values created via state (no ref.current access in render)
  const [y] = useState(() => new Animated.Value(-18));
  const [o] = useState(() => new Animated.Value(0));

  const [current, setCurrent] = useState<ToastPayload | null>(null);

  const queueRef = useRef<Array<ToastPayload>>([]);
  const timerRef = useRef<any>(null);

  // showRef avoids TDZ + hook dependency loops
  const showRef = useRef<(t: ToastPayload) => void>(() => {});

  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const drainQueue = useCallback(() => {
    const next = queueRef.current.shift();
    if (next) {
      requestAnimationFrame(() => showRef.current(next));
    }
  }, []);

  const hide = useCallback(() => {
    clearTimer();
    Animated.parallel([
      Animated.timing(o, { duration: 140, toValue: 0, useNativeDriver: true }),
      Animated.timing(y, {
        duration: 140,
        toValue: -18,
        useNativeDriver: true,
      }),
    ]).start(() => {
      setCurrent(null);
      drainQueue();
    });
  }, [clearTimer, drainQueue, o, y]);

  const enqueueOrSet = useCallback((t: ToastPayload) => {
    setCurrent((prev) => {
      if (prev) {
        queueRef.current.push(t);
        return prev;
      }
      return t;
    });
  }, []);

  useEffect(() => {
    showRef.current = enqueueOrSet;
  }, [enqueueOrSet]);

  // Animate whenever we have an active toast
  useEffect(() => {
    if (!current) {
      return;
    }

    y.setValue(-18);
    o.setValue(0);

    Animated.parallel([
      Animated.timing(o, { duration: 160, toValue: 1, useNativeDriver: true }),
      Animated.spring(y, {
        bounciness: 6,
        speed: 18,
        toValue: 0,
        useNativeDriver: true,
      }),
    ]).start(() => {
      clearTimer();
      timerRef.current = setTimeout(() => hide(), current.durationMs ?? 2400);
    });

    return () => clearTimer();
  }, [clearTimer, current, hide, o, y]);

  const api = useMemo<ToastApi>(
    () => ({
      error: (message, title) =>
        showRef.current({ message, title, type: 'error' }),
      info: (message, title) =>
        showRef.current({ message, title, type: 'info' }),
      show: (t) => showRef.current(t),
      success: (message, title) =>
        showRef.current({ message, title, type: 'success' }),
    }),
    [],
  );

  const palette =
    current?.type === 'success'
      ? { bg: theme.colors.primarySoft, border: 'rgba(0,177,79,0.22)' }
      : current?.type === 'error'
        ? { bg: 'rgba(239,68,68,0.10)', border: 'rgba(239,68,68,0.22)' }
        : { bg: theme.colors.surface, border: theme.colors.border };

  const styles = useMemo(
    () =>
      StyleSheet.create({
        wrapper: {
          left: 12,
          position: 'absolute',
          right: 12,
          top: Platform.select({ default: 18, ios: 54 }) as number,
          zIndex: 9999,
        },
      }),
    [],
  );

  return (
    <ToastContext.Provider value={api}>
      {children}

      {current ? (
        <Animated.View
          pointerEvents="box-none"
          style={[
            styles.wrapper,
            { opacity: o, transform: [{ translateY: y }] },
          ]}
        >
          <Pressable
            onPress={hide}
            style={[
              {
                backgroundColor: palette.bg,
                borderColor: palette.border,
                borderRadius: theme.radius.xl,
                borderWidth: 1,
                paddingHorizontal: 12,
                paddingVertical: 10,
              },
              theme.shadow.floating,
            ]}
          >
            {current.title ? (
              <Text
                className="text-[12px] font-medium"
                style={{ color: theme.colors.text }}
              >
                {current.title}
              </Text>
            ) : null}

            <Text
              className="mt-0.5 text-[11px]"
              style={{ color: theme.colors.textMuted }}
            >
              {current.message}
            </Text>

            <Text
              className="mt-2 text-[10px]"
              style={{ color: theme.colors.textMuted }}
            >
              Tap to dismiss
            </Text>
          </Pressable>
        </Animated.View>
      ) : null}
    </ToastContext.Provider>
  );
}

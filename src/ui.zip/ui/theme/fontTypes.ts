import type { TextStyle } from 'react-native';

export type RNFontWeight = NonNullable<TextStyle['fontWeight']>;

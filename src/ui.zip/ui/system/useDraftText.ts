// src/ui/system/useDraftText.ts
import { useCallback, useEffect, useRef, useState } from 'react';
import { getStorage } from './optionalStorage';

/**
 * Autosave draft text (ChatGPT-style interruption-safe typing).
 * Backward compatible:
 * - Uses optional storage if present; otherwise falls back to in-memory.
 * - Debounced writes to avoid perf issues.
 */
export function useDraftText(key: string, opts?: { debounceMs?: number; initial?: string }) {
  const debounceMs = opts?.debounceMs ?? 350;
  const [value, setValue] = useState(opts?.initial ?? '');
  const [hydrated, setHydrated] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);

  const storageRef = useRef<Awaited<ReturnType<typeof getStorage>> | null>(null);
  const timerRef = useRef<any>(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  // hydrate once
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const storage = await getStorage();
      storageRef.current = storage;
      try {
        const v = await storage.getItem(key);
        if (cancelled || !mountedRef.current) return;
        if (typeof v === 'string') {
          setValue(v);
        }
      } catch {}
      if (!cancelled && mountedRef.current) {
        setHydrated(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [key]);

  const persist = useCallback(
    (next: string) => {
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(async () => {
        try {
          const storage = storageRef.current ?? (await getStorage());
          storageRef.current = storage;

          if (!next) {
            await storage.removeItem(key);
          } else {
            await storage.setItem(key, next);
          }
          if (mountedRef.current) setLastSavedAt(Date.now());
        } catch {}
      }, debounceMs);
    },
    [debounceMs, key],
  );

  const setAndPersist = useCallback(
    (next: string) => {
      setValue(next);
      persist(next);
    },
    [persist],
  );

  const clear = useCallback(() => {
    setValue('');
    persist('');
  }, [persist]);

  return {
    value,
    setValue: setAndPersist,
    clear,
    hydrated,
    lastSavedAt,
  };
}

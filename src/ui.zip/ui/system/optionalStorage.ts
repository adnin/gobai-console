// src/ui/system/optionalStorage.ts
// Runtime-safe optional storage adapter.
// - Prefers @react-native-async-storage/async-storage (if installed)
// - Falls back to expo-secure-store (if installed)
// - Falls back to in-memory (always works; not persisted across restarts)

type KV = { [k: string]: string | undefined };

const mem: KV = {};

async function optionalImport(path: string): Promise<any | null> {
  try {
    const importer = new Function('p', 'return import(p)') as (p: string) => Promise<any>;
    return await importer(path);
  } catch {
    return null;
  }
}

export type StorageAdapter = {
  getItem: (key: string) => Promise<string | null>;
  setItem: (key: string, value: string) => Promise<void>;
  removeItem: (key: string) => Promise<void>;
};

export async function getStorage(): Promise<StorageAdapter> {
  const asyncStorageMod = await optionalImport('@react-native-async-storage/async-storage');
  if (asyncStorageMod?.default) {
    const AS = asyncStorageMod.default;
    return {
      getItem: (k) => AS.getItem(k),
      setItem: (k, v) => AS.setItem(k, v),
      removeItem: (k) => AS.removeItem(k),
    };
  }

  const secureStoreMod = await optionalImport('expo-secure-store');
  if (secureStoreMod) {
    const SS = secureStoreMod;
    return {
      getItem: (k) => SS.getItemAsync(k),
      setItem: (k, v) => SS.setItemAsync(k, v),
      removeItem: (k) => SS.deleteItemAsync(k),
    };
  }

  return {
    getItem: async (k) => mem[k] ?? null,
    setItem: async (k, v) => {
      mem[k] = v;
    },
    removeItem: async (k) => {
      delete mem[k];
    },
  };
}

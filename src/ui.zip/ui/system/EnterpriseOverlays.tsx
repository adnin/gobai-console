﻿import Text from '@/src/ui/Text';
import useViewerContext from '@/src/user/useViewerContext';
import React, { useMemo } from 'react';
import { ActivityIndicator, Platform, View } from 'react-native';
import { useTheme } from 'styled-components/native';
import { useOnlineStatus } from './useOnlineStatus';

export function OfflineBanner() {
  const theme = useTheme();
  const online = useOnlineStatus();

  if (online) {
    return null;
  }

  return (
    <View
      style={{
        backgroundColor: 'rgba(245,158,11,0.14)',
        borderColor: 'rgba(245,158,11,0.25)',
        borderRadius: theme.radius.xl,
        borderWidth: 1,
        left: 12,
        paddingHorizontal: 10,
        paddingVertical: 8,
        position: 'absolute',
        right: 12,
        top: Platform.select({ default: 12, ios: 12 }),
        zIndex: 9998,
      }}
    >
      <Text
        className="text-[11px] font-medium"
        style={{ color: theme.colors.text }}
      >
        You’re offline
      </Text>
      <Text
        className="mt-0.5 text-[10px]"
        style={{ color: theme.colors.textMuted }}
      >
        Some actions may fail. We’ll reconnect automatically.
      </Text>
    </View>
  );
}

export function GlobalAuthHud() {
  const theme = useTheme();
  const ctx: any = useViewerContext();

  // ✅ robust: works even if your context names differ
  const busy = Boolean(
    ctx?.booting ??
    ctx?.isBooting ??
    ctx?.authLoading ??
    ctx?.loading ??
    ctx?.isLoading ??
    ctx?.hydrating ??
    ctx?.isHydrating ??
    false,
  );

  const label = useMemo(() => {
    if (!busy) {
      return '';
    }
    return 'Securing session…';
  }, [busy]);

  if (!busy) {
    return null;
  }

  return (
    <View
      pointerEvents="none"
      style={{
        alignItems: 'center',
        backgroundColor:
          theme.mode === 'dark' ? 'rgba(0,0,0,0.28)' : 'rgba(15,23,42,0.08)',
        bottom: 0,
        justifyContent: 'center',
        left: 0,
        position: 'absolute',
        right: 0,
        top: 0,
        zIndex: 9997,
      }}
    >
      <View
        style={{
          alignItems: 'center',
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.border,
          borderRadius: theme.radius['2xl'],
          borderWidth: 1,
          minWidth: 220,
          paddingHorizontal: 16,
          paddingVertical: 14,
          ...theme.shadow.floating,
        }}
      >
        <ActivityIndicator />
        <Text
          className="mt-2 text-[12px] font-medium"
          style={{ color: theme.colors.text }}
        >
          {label}
        </Text>
        <Text
          className="mt-1 text-[10px]"
          style={{ color: theme.colors.textMuted }}
        >
          Please don’t close the app
        </Text>
      </View>
    </View>
  );
}

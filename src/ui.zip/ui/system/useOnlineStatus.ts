import { useEffect, useState } from 'react';

type NetState = {
  isConnected?: boolean | null;
  isInternetReachable?: boolean | null;
};

// Runtime-only import that avoids TS/ESLint module resolution
async function optionalImport(path: string): Promise<any | null> {
  try {
    const importer = new Function('p', 'return import(p)') as (
      p: string,
    ) => Promise<any>;
    return await importer(path);
  } catch {
    return null;
  }
}

export function useOnlineStatus() {
  const [online, setOnline] = useState(true);

  useEffect(() => {
    let unsub: null | (() => void) = null;
    let pollId: any = null;
    let cancelled = false;

    const setFrom = (s: NetState) => {
      const ok = Boolean(s.isConnected) && (s.isInternetReachable ?? true);
      setOnline(ok);
    };

    (async () => {
      // ✅ Try NetInfo if present
      const netinfoMod = await optionalImport(
        '@react-native-community/netinfo',
      );
      if (netinfoMod?.default) {
        const NetInfo = netinfoMod.default;
        unsub = NetInfo.addEventListener((s: any) =>
          setFrom({
            isConnected: s.isConnected,
            isInternetReachable: s.isInternetReachable,
          }),
        );
        NetInfo.fetch?.()
          .then((s: any) =>
            setFrom({
              isConnected: s.isConnected,
              isInternetReachable: s.isInternetReachable,
            }),
          )
          .catch(() => {});
        return;
      }

      // ✅ Fallback to expo-network polling if present
      const networkMod = await optionalImport('expo-network');
      if (networkMod) {
        const Network = networkMod;
        const check = async () => {
          try {
            const s: any = await Network.getNetworkStateAsync();
            if (cancelled) {
              return;
            }
            setFrom({
              isConnected: s.isConnected,
              isInternetReachable: s.isInternetReachable,
            });
          } catch {}
        };

        await check();
        pollId = setInterval(check, 6000);
      }
      // If neither exists, we stay "online" and show no banner.
    })();

    return () => {
      cancelled = true;
      unsub?.();
      if (pollId) {
        clearInterval(pollId);
      }
    };
  }, []);

  return online;
}

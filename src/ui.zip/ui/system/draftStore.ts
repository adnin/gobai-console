import { optionalImport } from './optionalImport';

type StorageLike = {
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
  removeItem(key: string): Promise<void>;
};

// In-memory fallback so the app still works even without AsyncStorage.
const mem = new Map<string, string>();

async function getStorage(): Promise<StorageLike> {
  const mod = await optionalImport('@react-native-async-storage/async-storage');
  const AsyncStorage: any = mod?.default ?? mod;
  if (AsyncStorage?.getItem && AsyncStorage?.setItem) {
    return AsyncStorage as StorageLike;
  }

  // Expo SecureStore can be used too, but it may not exist and it has size limits.
  // We only use it if AsyncStorage isn't available.
  const secure = await optionalImport('expo-secure-store');
  const SecureStore: any = secure?.default ?? secure;
  if (SecureStore?.getItemAsync && SecureStore?.setItemAsync) {
    return {
      async getItem(key: string) {
        return (await SecureStore.getItemAsync(key)) ?? null;
      },
      async setItem(key: string, value: string) {
        await SecureStore.setItemAsync(key, value);
      },
      async removeItem(key: string) {
        await SecureStore.deleteItemAsync(key);
      },
    };
  }

  return {
    async getItem(key: string) {
      return mem.get(key) ?? null;
    },
    async setItem(key: string, value: string) {
      mem.set(key, value);
    },
    async removeItem(key: string) {
      mem.delete(key);
    },
  };
}

export async function draftGet(key: string): Promise<string | null> {
  const storage = await getStorage();
  try {
    return await storage.getItem(key);
  } catch {
    return null;
  }
}

export async function draftSet(key: string, value: string): Promise<void> {
  const storage = await getStorage();
  try {
    await storage.setItem(key, value);
  } catch {
    // ignore
  }
}

export async function draftRemove(key: string): Promise<void> {
  const storage = await getStorage();
  try {
    await storage.removeItem(key);
  } catch {
    // ignore
  }
}

// Runtime-only import helper that avoids TS/ESLint module resolution.
//
// Use this for optional dependencies (AsyncStorage, NetInfo, etc.) so the UI
// layer stays backward-compatible across older app builds.

export async function optionalImport(path: string): Promise<any | null> {
  try {
    // eslint-disable-next-line no-new-func
    const importer = new Function('p', 'return import(p)') as (
      p: string,
    ) => Promise<any>;
    return await importer(path);
  } catch {
    return null;
  }
}

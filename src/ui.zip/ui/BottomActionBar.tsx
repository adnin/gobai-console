﻿import Text from '@/src/ui/Text';
import { useAppTheme } from '@/src/ui/themed';
import React, { memo } from 'react';
import type { ViewStyle } from 'react-native';
import { Pressable, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const dot = (color: string): ViewStyle => ({
  backgroundColor: color,
  borderRadius: 999,
  height: 10,
  width: 10,
});

export const BottomActionBarAction = memo(function BottomActionBarAction({
  disabled,
  Icon,
  iconColor,
  onPress,
  primary,
  title,
}: {
  disabled?: boolean;
  Icon: any;
  iconColor: string;
  onPress: () => void;
  primary?: boolean;
  title: string;
}) {
  const theme = useAppTheme();

  return (
    <Pressable
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        {
          alignItems: 'center',
          backgroundColor: primary
            ? theme.colors.primary
            : theme.colors.surface,
          borderColor: primary ? 'transparent' : theme.colors.border,
          borderRadius: theme.radius['2xl'],
          borderWidth: primary ? 0 : 1,
          flex: 1,
          flexDirection: 'row',
          gap: theme.space[2],
          height: theme.space[12],
          justifyContent: 'center',
          opacity: disabled ? 0.55 : pressed ? 0.9 : 1,
        },
        primary ? theme.shadow.floating : theme.shadow.card,
      ]}
    >
      <Icon color={primary ? '#fff' : iconColor} size={16} strokeWidth={2.6} />
      <Text
        style={{
          color: primary ? '#fff' : theme.colors.text,
          fontSize: theme.font.size.xs,
          fontWeight: theme.font.weight.medium,
        }}
      >
        {title}
      </Text>
    </Pressable>
  );
});

export const BottomActionBar = memo(function BottomActionBar({
  actions,
}: {
  actions: Array<{
    disabled?: boolean;
    Icon: any;
    iconColor?: string;
    onPress: () => void;
    primary?: boolean;
    title: string;
  }>;
}) {
  const theme = useAppTheme();

  return (
    <SafeAreaView
      edges={['bottom']}
      style={{ bottom: 0, left: 0, position: 'absolute', right: 0 }}
    >
      <View
        style={{
          backgroundColor: theme.colors.bg,
          borderTopColor: theme.colors.border,
          borderTopWidth: 1,
          paddingBottom: theme.space[2],
          paddingHorizontal: theme.space[4],
          paddingTop: theme.space[2],
        }}
      >
        <View style={{ flexDirection: 'row', gap: theme.space[2] }}>
          {actions.map((a) => (
            <BottomActionBarAction
              disabled={a.disabled}
              Icon={a.Icon}
              iconColor={a.iconColor ?? theme.colors.text}
              key={a.title}
              onPress={a.onPress}
              primary={a.primary}
              title={a.title}
            />
          ))}
        </View>
      </View>
    </SafeAreaView>
  );
});

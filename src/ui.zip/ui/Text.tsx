import React, { ReactNode, useMemo } from 'react';
// eslint-disable-next-line @typescript-eslint/no-restricted-imports
import { Text as ReactNativeText, TextProps } from 'react-native';
import { cx } from '../lib/cx.tsx';

function hasExplicitTextColor(className?: string) {
  if (!className) {
    return false;
  }

  // Covers common NativeWind patterns:
  // text-gray-900, text-white, text-[#00b14f], text-[var(--text)], etc.
  return (
    className.includes('text-') ||
    className.includes('text[') ||
    className.includes('text-[') ||
    className.includes('color-[')
  );
}

type Props = {
  children?: ReactNode;
  className?: string;
} & TextProps;

export default function Text({ children, className, style, ...props }: Props) {
  const base = useMemo(() => {
    // If caller provides explicit text color, don't override.
    // Otherwise default to your theme variable.
    return hasExplicitTextColor(className) ? '' : 'text-[var(--text)]';
  }, [className]);

  return (
    <ReactNativeText
      {...props}
      className={cx(base, className)}
      style={style}
      suppressHighlighting
    >
      {children}
    </ReactNativeText>
  );
}

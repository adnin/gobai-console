import type { ViewStyle } from 'react-native';
import type { Theme } from './themed';

type CommonStyles = {
  card: ViewStyle;
  center: ViewStyle;
  page: ViewStyle;
  row: ViewStyle;
  rowBetween: ViewStyle;
  screen: ViewStyle;
};

export function makeCommonStyles(theme: Theme): CommonStyles {
  return {
    card: {
      backgroundColor: theme.colors.surface,
      borderColor: theme.colors.border,
      borderRadius: theme.radius.lg,
      borderWidth: 1,
      padding: theme.space[4],
    },
    center: {
      alignItems: 'center',
      justifyContent: 'center',
    },
    page: {
      flex: 1,
      padding: theme.space[4],
    },
    row: {
      alignItems: 'center',
      flexDirection: 'row',
    },
    rowBetween: {
      alignItems: 'center',
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    screen: {
      backgroundColor: theme.colors.bg,
      flex: 1,
    },
  };
}

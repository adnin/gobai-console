import { Link, useLocation } from "react-router-dom";

const tabs = [
  { to: "/merchant", label: "Orders" },
  { to: "/merchant/products", label: "Products" },
  { to: "/merchant/wallet", label: "Wallet" },
  { to: "/merchant/payouts", label: "Payouts" },
  { to: "/merchant/store", label: "Store" },
  { to: "/merchant/audit", label: "Audit" },
  { to: "/merchant/upgrade", label: "Upgrade" },
];

export function MerchantTabs() {
  const loc = useLocation();
  const path = loc.pathname;

  return (
    <div className="mb-4 flex flex-wrap gap-2">
      {tabs.map((t) => {
        const active = path === t.to || (t.to !== "/merchant" && path.startsWith(t.to));
        return (
          <Link
            key={t.to}
            to={t.to}
            className={
              "rounded-full border px-3 py-1 text-sm transition " +
              (active
                ? "border-foreground/30 bg-foreground/5 font-semibold"
                : "border-border bg-background hover:bg-muted/30")
            }
          >
            {t.label}
          </Link>
        );
      })}
    </div>
  );
}
